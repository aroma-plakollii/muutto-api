<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function register(Request $request) {
        $fields = $request->validate([
            'name' => 'required|min:4|string',
            'email' => 'required|email|string',
            'password' => 'required|min:8|string',
        ]);

        $user = User::create([
            'name' => $fields['name'],
            'email' => $fields['email'],
            'password' => Hash::make($fields['password'])
        ]);

        $token = $user->createToken('API_TOKEN')->accessToken;

        return response()->json([
            'user' => $user,
            'token' => $token
        ], 201);

    }

    public function login(Request $request){
        $fields = $request->validate([
            'email' => 'required|email|string',
            'password' => 'required|string',
        ]);

        $user = User::where('email', $fields['email'])->with('company')->first();

        if (!Auth::attempt(['email' => $fields['email'], 'password' => $fields['password']]))
        {
            return response([
                'message' => 'Check login credentials'
            ], 401);
        }

        $token = $user->createToken('API_TOKEN', ['server:update'])->plainTextToken;

        return response()->json([
            'user' => $user,
            'token' => $token
        ], 201);

    }

    public function logout(Request $request){
        $request->user()->currentAccessToken()->delete();

        return ['Logged out'];
    }

    public function index(){
        return User::all();
    }
}
